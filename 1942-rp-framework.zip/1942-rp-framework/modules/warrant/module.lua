﻿MODULE.name = "Warrants"
MODULE.author = "76561198312513285"
MODULE.discord = "@liliaplayer"
MODULE.desc = "Adds Warrants"
lia.flag.add(MODULE.WarrantFlag, "Adds Warrant Flag")
