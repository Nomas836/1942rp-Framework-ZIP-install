﻿lia.command.add("warrant", {
    adminOnly = false,
    onRun = function() end
})
