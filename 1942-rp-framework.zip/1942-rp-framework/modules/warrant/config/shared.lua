﻿MODULE.RemoveWarrantOnDeath = true
MODULE.WarrantFlag = "P"
