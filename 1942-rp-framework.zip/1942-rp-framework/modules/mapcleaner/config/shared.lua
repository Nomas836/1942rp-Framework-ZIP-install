﻿MODULE.MapCleanerEnabled = true
MODULE.ItemCleanupTime = 7200
MODULE.MapCleanupTime = 21600
MODULE.MapCleanerEntitiesToRemove = {"lia_item", "prop_physics"}
