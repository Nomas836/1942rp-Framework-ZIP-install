﻿MODULE.name = "Map Cleaner"
MODULE.author = "76561198312513285"
MODULE.discord = "@liliaplayer"
MODULE.desc = "Adds a Map Cleaner with configurable timings"
