﻿lia.command.add("doorkick", {
    syntax = "",
    onRun = function() end
})

lia.command.add("doorid", {
    adminOnly = true,
    onRun = function() end
})
