﻿MODULE.KickDoorBlacklistedFactions = {FACTION_CITIZEN}
