--- Configuration for Door Kick Module.
-- @configuration DoorKick

--- This table defines the default settings for the Door Kick Module.
-- @realm shared
-- @table Configuration
-- @field KickDoorBlacklistedFactions Specifies factions that are blacklisted from door kicking | **table**