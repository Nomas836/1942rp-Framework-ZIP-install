--- Configuration for Loyalism Module.
-- @configuration Loyalism

--- This table defines the default settings for the Loyalism Module.
-- @realm shared
-- @table Configuration
-- @field A table defining the tiers and their corresponding titles for party members | **table**