﻿lia.command.add("partytier", {
    adminOnly = true,
    privilege = "Management - Assign Party Tiers",
    syntax = "<string name> <string number>",
    onRun = function() end
})
