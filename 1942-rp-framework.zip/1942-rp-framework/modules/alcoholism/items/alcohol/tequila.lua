﻿ITEM.name = "Tequila"
ITEM.model = "models/mark2580/gtav/barstuff/tequila_bottle.mdl"
ITEM.uniqueID = "tequila"
ITEM.width = 1
ITEM.height = 1
ITEM.abv = 20
ITEM.sound = "eating_and_drinking/drinking.wav"
