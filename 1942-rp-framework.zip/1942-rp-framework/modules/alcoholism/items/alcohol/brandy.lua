﻿ITEM.name = "Brandy"
ITEM.model = "models/mark2580/gtav/barstuff/bottle_brandy.mdl"
ITEM.uniqueID = "brandy"
ITEM.width = 1
ITEM.height = 1
ITEM.abv = 13
ITEM.sound = "eating_and_drinking/drinking.wav"
