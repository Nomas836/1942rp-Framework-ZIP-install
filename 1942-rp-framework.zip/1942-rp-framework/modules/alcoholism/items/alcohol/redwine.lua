﻿ITEM.name = "Red Wine"
ITEM.model = "models/mark2580/gtav/barstuff/wine_red.mdl"
ITEM.uniqueID = "redwine"
ITEM.width = 1
ITEM.height = 1
ITEM.abv = 20
ITEM.sound = "eating_and_drinking/drinking.wav"
