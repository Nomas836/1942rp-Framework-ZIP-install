﻿ITEM.name = "Rum"
ITEM.model = "models/mark2580/gtav/barstuff/rum_bottle_2.mdl"
ITEM.uniqueID = "rum"
ITEM.width = 1
ITEM.height = 1
ITEM.abv = 20
ITEM.sound = "eating_and_drinking/drinking.wav"
