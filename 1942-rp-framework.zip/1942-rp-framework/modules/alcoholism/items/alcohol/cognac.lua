﻿ITEM.name = "Cognac"
ITEM.model = "models/mark2580/gtav/barstuff/bottle_cognac_2.mdl"
ITEM.uniqueID = "cognac"
ITEM.width = 1
ITEM.height = 1
ITEM.abv = 20
ITEM.sound = "eating_and_drinking/drinking.wav"
