﻿ITEM.name = "Champagne"
ITEM.model = "models/mark2580/gtav/barstuff/champ_jer_01a.mdl"
ITEM.uniqueID = "champagne"
ITEM.width = 1
ITEM.height = 1
ITEM.abv = 13
ITEM.sound = "eating_and_drinking/drinking.wav"
