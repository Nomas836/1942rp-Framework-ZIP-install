﻿ITEM.name = "Beer"
ITEM.model = "models/mark2580/gtav/barstuff/beer_logger.mdl"
ITEM.uniqueID = "beer"
ITEM.width = 1
ITEM.height = 1
ITEM.abv = 13
ITEM.sound = "eating_and_drinking/drinking.wav"
