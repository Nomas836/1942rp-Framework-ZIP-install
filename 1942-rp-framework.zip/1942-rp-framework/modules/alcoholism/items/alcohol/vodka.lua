﻿ITEM.name = "Vodka"
ITEM.model = "models/mark2580/gtav/barstuff/vodka_bottle.mdl"
ITEM.width = 1
ITEM.height = 2
ITEM.abv = 20
ITEM.sound = "eating_and_drinking/drinking.wav"
ITEM.price = 30
