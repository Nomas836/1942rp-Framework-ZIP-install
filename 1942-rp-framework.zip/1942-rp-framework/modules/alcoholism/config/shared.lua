﻿MODULE.TickTime = 30
MODULE.DegradeRate = 5
MODULE.AddAlpha = 0.03
MODULE.EffectDelay = 0.03
MODULE.DrunkNotifyThreshold = 50
