﻿MODULE.name = "Alcoholism"
MODULE.author = "76561198312513285"
MODULE.discord = "@liliaplayer"
MODULE.desc = "Adds Alcohol and Effects to it."
