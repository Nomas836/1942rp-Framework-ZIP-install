﻿MODULE.name = "War Table"
MODULE.author = "76561198312513285"
MODULE.discord = "@liliaplayer"
MODULE.desc = "Adds a interactive War Table"
