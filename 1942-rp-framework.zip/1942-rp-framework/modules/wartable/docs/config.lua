--- Configuration for War Table Module.
-- @configuration WarTable

--- This table defines the default settings for the War Table Module.
-- @realm shared
-- @table Configuration
-- @field allowedImageTypes Allowed image types for the module | **table**
-- @field  URL to the default image | **string**