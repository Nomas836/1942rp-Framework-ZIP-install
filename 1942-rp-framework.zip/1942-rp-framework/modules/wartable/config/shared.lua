﻿MODULE.allowedImageTypes = {".PNG", ".JPG", ".JPEG"}
MODULE.URL = "https://cdn.discordapp.com/attachments/1059867063902019677/1073743159017885706/432b60eb74bc53305dc3a5ccc573335c1.png"
