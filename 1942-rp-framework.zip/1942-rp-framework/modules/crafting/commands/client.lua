﻿lia.command.add("craftlock", {
    adminOnly = false,
    syntax = "",
    onRun = function() end
})

lia.command.add("craftunlock", {
    adminOnly = false,
    syntax = "",
    onRun = function() end
})
