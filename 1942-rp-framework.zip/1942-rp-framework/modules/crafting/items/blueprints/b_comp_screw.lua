﻿ITEM.name = "Screws Blueprint"
ITEM.desc = "."
ITEM.category = "Crafting"
ITEM.price = 25
ITEM.noBusiness = true
ITEM.requirements = {{"iron_bar", 1}, {"copper_bar", 1}, {"coal", 1}}
ITEM.result = {{"screws", 4},}
