﻿ITEM.name = "Gears Blueprint"
ITEM.desc = "."
ITEM.category = "Crafting"
ITEM.price = 25
ITEM.noBusiness = true
ITEM.requirements = {{"iron_bar", 2}, {"coal", 2}}
ITEM.result = {{"gears", 6},}
