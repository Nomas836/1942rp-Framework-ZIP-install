﻿ITEM.category = "Components"
ITEM.name = "Empty Cigar Box"
ITEM.desc = "An Empty Cigar Box."
ITEM.model = "models/polievka/cigarbox.mdl"
ITEM.price = 7
ITEM.width = 1
ITEM.length = 1
