﻿ITEM.category = "Components"
ITEM.name = "Rolling Paper"
ITEM.desc = "A Wheel Of Rolling Paper."
ITEM.model = "models/mosi/fallout4/props/junk/ducttape.mdl"
ITEM.price = 11
ITEM.width = 1
ITEM.length = 1
