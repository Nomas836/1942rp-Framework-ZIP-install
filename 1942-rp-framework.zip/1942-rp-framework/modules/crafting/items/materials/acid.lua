﻿ITEM.category = "Components"
ITEM.name = "Sulphuric Acid"
ITEM.desc = "A Pot Of Sulphuric Acid."
ITEM.model = "models/mosi/fallout4/props/junk/components/acid.mdl"
ITEM.price = 111
ITEM.width = 1
ITEM.length = 1
