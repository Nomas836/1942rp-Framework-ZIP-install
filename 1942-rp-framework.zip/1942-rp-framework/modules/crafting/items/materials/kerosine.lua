﻿ITEM.category = "Components"
ITEM.name = "Kerosine"
ITEM.desc = "A Jerry Can Of Kerosine."
ITEM.model = "models/props_junk/metalgascan.mdl"
ITEM.price = 156
ITEM.width = 1
ITEM.length = 1
