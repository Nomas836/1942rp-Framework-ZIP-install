﻿ITEM.category = "Components"
ITEM.name = "Leather"
ITEM.desc = "A Roll Of Leather."
ITEM.model = "models/mosi/fallout4/props/junk/components/leather.mdl"
ITEM.price = 55
ITEM.width = 1
ITEM.length = 1
