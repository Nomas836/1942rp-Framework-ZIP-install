﻿ITEM.category = "Components"
ITEM.name = "Buttons"
ITEM.desc = "A Box Of Buttons."
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.price = 55
ITEM.width = 1
ITEM.length = 1
