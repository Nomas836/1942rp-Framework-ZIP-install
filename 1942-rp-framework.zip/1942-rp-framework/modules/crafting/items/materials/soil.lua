﻿ITEM.category = "Farming"
ITEM.name = "Soil"
ITEM.desc = "A Sack Of Potting Soil."
ITEM.model = "models/gonzo/weedb/soil_bag.mdl"
ITEM.price = 9
ITEM.width = 1
ITEM.length = 1
