﻿ITEM.category = "Components"
ITEM.name = "Springs"
ITEM.desc = "A Box Of Springs."
ITEM.model = "models/mosi/fallout4/props/junk/components/springs.mdl"
ITEM.price = 18
ITEM.width = 1
ITEM.length = 1
