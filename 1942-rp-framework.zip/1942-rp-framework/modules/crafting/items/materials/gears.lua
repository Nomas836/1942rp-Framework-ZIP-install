﻿ITEM.category = "Components"
ITEM.name = "Gears"
ITEM.desc = "A Box Of Gears."
ITEM.model = "models/mosi/fallout4/props/junk/components/gears.mdl"
ITEM.price = 23
ITEM.width = 1
ITEM.length = 1
