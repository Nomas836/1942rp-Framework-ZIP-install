﻿ITEM.category = "Components"
ITEM.name = "Wool"
ITEM.desc = "A Roll Of Wool."
ITEM.model = "models/mosi/fallout4/props/junk/components/fiberglass.mdl"
ITEM.price = 29
ITEM.width = 1
ITEM.length = 1
