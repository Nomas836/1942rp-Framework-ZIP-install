﻿ITEM.category = "Farming"
ITEM.name = "Fertilizer"
ITEM.desc = "A Sack Of Fertilizer."
ITEM.model = "models/mosi/fallout4/props/junk/fertilizerbag.mdl"
ITEM.price = 3
ITEM.width = 1
ITEM.length = 1
