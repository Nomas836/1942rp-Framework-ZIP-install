﻿ITEM.category = "Components"
ITEM.name = "Fabric"
ITEM.desc = "A Roll Of Fabric."
ITEM.model = "models/mosi/fallout4/props/junk/components/cloth.mdl"
ITEM.price = 29
ITEM.width = 1
ITEM.length = 1
