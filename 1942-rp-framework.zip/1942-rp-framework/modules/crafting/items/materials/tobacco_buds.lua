﻿ITEM.category = "Farming"
ITEM.name = "Tobacco Bud"
ITEM.desc = "A Bud From A Tobacco Plant."
ITEM.model = "models/weapons/w_bugbait.mdl"
ITEM.price = 4
ITEM.width = 1
ITEM.length = 1
