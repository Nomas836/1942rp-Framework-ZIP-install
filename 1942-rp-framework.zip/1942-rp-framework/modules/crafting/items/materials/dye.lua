﻿ITEM.category = "Components"
ITEM.name = "Dye"
ITEM.desc = "A Bottle Of Dye."
ITEM.model = "models/props_lab/jar01b.mdl"
ITEM.price = 33
ITEM.width = 1
ITEM.length = 1
