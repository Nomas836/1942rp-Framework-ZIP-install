﻿ITEM.category = "Components"
ITEM.name = "Empty Cigarette Box"
ITEM.desc = "An Empty Cigarette Box."
ITEM.model = "models/mosi/fallout4/props/junk/cigarettepack.mdl"
ITEM.price = 2
ITEM.width = 1
ITEM.length = 1
