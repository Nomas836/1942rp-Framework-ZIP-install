﻿ITEM.category = "Components"
ITEM.name = "Gasoline"
ITEM.desc = "A Jerry Can Of Gasoline."
ITEM.model = "models/props_junk/gascan001a.mdl"
ITEM.price = 44
ITEM.width = 1
ITEM.length = 1
