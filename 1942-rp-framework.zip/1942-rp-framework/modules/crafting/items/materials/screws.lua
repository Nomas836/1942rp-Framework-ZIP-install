﻿ITEM.category = "Components"
ITEM.name = "Screws"
ITEM.desc = "A Box Of Screws."
ITEM.model = "models/mosi/fallout4/props/junk/components/screws.mdl"
ITEM.price = 5
ITEM.width = 1
ITEM.length = 1
