﻿ITEM.name = "Diamond Ring"
ITEM.desc = "An Shiny Diamond Ring."
ITEM.price = 0
