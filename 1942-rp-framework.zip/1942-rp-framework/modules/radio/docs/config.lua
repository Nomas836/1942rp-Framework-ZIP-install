--- Configuration for Radio Module.
-- @configuration Radio

--- This table defines the default settings for the Radio Module.
-- @realm shared
-- @table Configuration
-- @field RadioChatColor color The color used for radio chat messages