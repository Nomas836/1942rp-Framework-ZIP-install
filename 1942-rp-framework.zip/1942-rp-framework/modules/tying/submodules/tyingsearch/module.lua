﻿MODULE.name = "Search Tying Sub-Module"
MODULE.author = "76561198312513285"
MODULE.discord = "@liliaplayer"
MODULE.desc = "Adds Searching to Tying"
