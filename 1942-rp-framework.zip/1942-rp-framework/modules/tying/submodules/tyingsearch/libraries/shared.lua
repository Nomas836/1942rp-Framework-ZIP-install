﻿function IsBeingSearched(target)
    return target:getNetVar("searcher")
end
