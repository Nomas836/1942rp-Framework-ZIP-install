﻿lia.command.add("removeties", {
    privilege = "Remove Ties",
    adminOnly = true,
    syntax = "<string player>",
    onRun = function() end
})
