﻿function IsHandcuffed(target)
    return target:getNetVar("restricted", false)
end
