﻿MODULE.FlashlightEnabled = true
MODULE.FlashlightNeedsItem = true
MODULE.FlashlightCooldown = 0.5
MODULE.FlashlightItems = {"flashlight"}
