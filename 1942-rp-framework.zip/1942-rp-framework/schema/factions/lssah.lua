﻿FACTION.name = "Leibstandarte SS 'Adolf Hitler'"
FACTION.desc = ""
FACTION.color = Color(255, 0, 0)
FACTION.isDefault = false
FACTION.pay = 35
FACTION.isGloballyRecognized = false
FACTION_LSSAH = FACTION.index
