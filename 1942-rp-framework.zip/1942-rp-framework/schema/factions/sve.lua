﻿FACTION.name = "Tannhäuser"
FACTION.desc = "Tannhäuser Science Research"
FACTION.color = Color(51, 117, 232)
FACTION.isDefault = false
FACTION.pay = 30
FACTION.isGloballyRecognized = false
FACTION_SVE = FACTION.index
