﻿FACTION.name = "KdF and SA"
FACTION.desc = "The Fuhrers Chancellery and SA"
FACTION.color = Color(51, 117, 232)
FACTION.isDefault = false
FACTION.pay = 60
FACTION.isGloballyRecognized = false
FACTION_FD = FACTION.index
