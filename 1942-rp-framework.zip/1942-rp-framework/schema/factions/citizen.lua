﻿FACTION.name = "Citizens of Berlin"
FACTION.desc = "The Citizens of Berlin."
FACTION.color = Color(51, 117, 232)
FACTION.isDefault = true
FACTION.pay = 5
FACTION.isGloballyRecognized = false
FACTION.models = {"models/suits/male_04_shirt_tie.mdl", "models/suits/male_02_shirt_tie.mdl", "models/suits/male_06_shirt_tie.mdl", "models/suits/male_05_shirt_tie.mdl", "models/suits/male_09_shirt_tie.mdl",}
FACTION_CITIZEN = FACTION.index
