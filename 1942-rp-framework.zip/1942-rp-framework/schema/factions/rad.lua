﻿FACTION.name = "Reichsarbeitsdienst"
FACTION.desc = "The Reichsarbeitsdiens"
FACTION.color = Color(51, 117, 232)
FACTION.isDefault = false
FACTION.pay = 25
FACTION.isGloballyRecognized = false
FACTION_RAD = FACTION.index
