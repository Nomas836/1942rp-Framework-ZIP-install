﻿FACTION.name = "Ordnungspolizei"
FACTION.desc = "The Law Enforcement of Berlin"
FACTION.color = Color(0, 127, 31)
FACTION.isDefault = false
FACTION.pay = 30
FACTION.isGloballyRecognized = false
FACTION_ORPO = FACTION.index
