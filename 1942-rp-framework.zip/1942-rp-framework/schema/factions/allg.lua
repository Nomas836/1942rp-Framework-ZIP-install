﻿FACTION.name = "Allgemeine-SS"
FACTION.desc = "The General SS"
FACTION.color = Color(255, 0, 0)
FACTION.isDefault = false
FACTION.pay = 50
FACTION.isGloballyRecognized = false
FACTION_ALLG = FACTION.index
