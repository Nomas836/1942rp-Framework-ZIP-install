﻿FACTION.name = "Reichssicherheitshauptamt"
FACTION.desc = "The Security Office of Berlin."
FACTION.color = Color(255, 0, 0)
FACTION.isDefault = false
FACTION.pay = 40
FACTION.isGloballyRecognized = false
FACTION_RSHA = FACTION.index
