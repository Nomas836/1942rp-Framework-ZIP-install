﻿FACTION.name = "Nationalsozialistische Deutsche Arbeiterpartei"
FACTION.desc = "The Nazi Party"
FACTION.color = Color(255, 191, 0)
FACTION.isDefault = false
FACTION.pay = 50
FACTION.isGloballyRecognized = false
FACTION_NSDAP = FACTION.index
