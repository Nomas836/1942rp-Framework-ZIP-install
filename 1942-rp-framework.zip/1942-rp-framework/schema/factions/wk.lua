﻿FACTION.name = "Wehrkreis III"
FACTION.desc = "The Military of Germany"
FACTION.color = Color(51, 117, 232)
FACTION.isDefault = false
FACTION.pay = 35
FACTION.isGloballyRecognized = false
FACTION_WK3 = FACTION.index
