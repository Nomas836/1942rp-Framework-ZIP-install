﻿FACTION.name = "Oberkommando der Marine"
FACTION.desc = "The Military of Germany"
FACTION.color = Color(0, 161, 255)
FACTION.isDefault = false
FACTION.pay = 35
FACTION.isGloballyRecognized = false
FACTION_OKM = FACTION.index
