﻿FACTION.name = "Oberkommando der Luftwaffe"
FACTION.desc = "The Military of Germany"
FACTION.color = Color(169, 181, 0)
FACTION.isDefault = false
FACTION.pay = 35
FACTION.isGloballyRecognized = false
FACTION_OKL = FACTION.index
