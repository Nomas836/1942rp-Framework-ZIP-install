﻿FACTION.name = "Oberkommando des Heeres"
FACTION.desc = "The Military of Germany"
FACTION.color = Color(51, 117, 232)
FACTION.isDefault = false
FACTION.pay = 45
FACTION.isGloballyRecognized = false
FACTION_OKH = FACTION.index
