﻿FACTION.name = "Deutsche Arbeitsfront"
FACTION.desc = "The German Workers Front"
FACTION.color = Color(51, 117, 232)
FACTION.isDefault = false
FACTION.pay = 20
FACTION.isGloballyRecognized = false
FACTION_DAF = FACTION.index
