﻿FACTION.name = "Office der Führer"
FACTION.desc = "Office of The Führer"
FACTION.color = Color(255, 0, 0)
FACTION.isDefault = false
FACTION.pay = 150
FACTION.isGloballyRecognized = false
FACTION_FUHRER = FACTION.index
