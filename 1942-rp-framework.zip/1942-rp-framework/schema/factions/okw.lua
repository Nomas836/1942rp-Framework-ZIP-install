﻿FACTION.name = "Oberkommando der Wehrmacht"
FACTION.desc = "The Military of Germany"
FACTION.color = Color(63, 127, 0)
FACTION.isDefault = false
FACTION.pay = 60
FACTION.isGloballyRecognized = false
FACTION_OKW = FACTION.index
