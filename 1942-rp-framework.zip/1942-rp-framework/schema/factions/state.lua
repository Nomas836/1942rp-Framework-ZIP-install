﻿FACTION.name = "Reichsregierung"
FACTION.desc = "The Governement of Germany"
FACTION.color = Color(51, 117, 232)
FACTION.isDefault = false
FACTION.pay = 50
FACTION.isGloballyRecognized = false
FACTION_STATE = FACTION.index
