﻿DeriveGamemode("Nomas Framework")
