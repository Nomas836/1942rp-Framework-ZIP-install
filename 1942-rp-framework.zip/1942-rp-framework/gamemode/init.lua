﻿AddCSLuaFile("cl_init.lua")
DeriveGamemode("Nomas Framework")
