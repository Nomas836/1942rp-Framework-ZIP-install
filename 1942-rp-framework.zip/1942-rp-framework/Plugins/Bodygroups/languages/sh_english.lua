--[[
    BodygroupNS - A bodygroup menu and bodygroup closet for NutScript 1.2
    
    Created by DoopieWop
--]]

LANGUAGE = {
    bodygroupNSChanged = "You have changed %s bodygroups and/or skin.",
    bodygroupNSChangedBy = "%s has changed your bodygroups and/or skin.",

    invalidSkin = "Invalid skin!",
    invalidBodygroup = "Invalid bodygroup!",
}