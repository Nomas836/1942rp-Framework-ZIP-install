ATTRIBUTE.name = "Strength"
ATTRIBUTE.desc = "A measure of how strong you are."